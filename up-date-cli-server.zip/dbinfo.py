db_host = 'update.cuhxyhjtupdm.ap-northeast-2.rds.amazonaws.com'
db_username = 'admin'
db_password = 'Soongsil12!'
db_name = 'upd4te'
db_port = 3306