import pymysql
import dbinfo
import json

from response import get_success_schema, get_error_schema

connection = pymysql.connect(
    host=dbinfo.db_host,
    user=dbinfo.db_username,
    passwd=dbinfo.db_password,
    db=dbinfo.db_name,
    port=dbinfo.db_port
)

cursor = connection.cursor()  # DB에 접속 및 DB 객체를 가져옴

def get_user(path_parameters):
    query = f"""
    SELECT
        id,
        email
    FROM
        users
    WHERE
        users.id = {path_parameters['id']}
    """

    cursor.execute(query)
    rows = cursor.fetchall()

    if len(rows) == 0:
        return get_error_schema(404, '존재하지 않는 유저입니다.')
    else:
        user = rows[0]
        result = {
            'id': user['id'],
            'email': user['email']
        }

        return get_success_schema(200, result)